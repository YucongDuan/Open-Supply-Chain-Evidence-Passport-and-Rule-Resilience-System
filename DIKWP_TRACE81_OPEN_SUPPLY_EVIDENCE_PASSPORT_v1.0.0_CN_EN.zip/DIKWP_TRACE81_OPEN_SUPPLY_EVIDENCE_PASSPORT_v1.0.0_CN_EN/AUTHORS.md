# Authors and attribution

- Concept, DIKWP framework, and project attribution: **Yucong Duan (段玉聪)**
- Reference implementation and release engineering: developed for the Yucong Duan open-source research programme.

The demonstration entities, facilities, lots, shipments, and evidence files are fictional. Official rule-pack source facts are attributed in the rule-pack and documentation.
