# Data model / 数据模型

## 核心对象

- `organizations`: 法律名称、别名、注册标识、地区和角色；
- `facilities`: 工厂、农场、仓库或加工地点；
- `products`: 产品或物料主数据；
- `lots`: 具体批次、数量、单位和生产时间；
- `events`: Object/Transformation/Aggregation/Association 等事件；
- `relations`: 供应、控制、加工或其他关系；
- `shipments`: 出口商、进口商、起运/到达与入境记录；
- `evidence`: 来源、签发方、有效期、文件摘要、保密级别和声明；
- `cases`: 市场、规则包、货运和审查状态；
- `audit_log`: 追加式哈希链。

## 隐私分层

- `public`: 可在公共护照中披露；
- `restricted`: 仅在鉴证/律师/进口商视图中披露；
- 实际部署应增加字段级授权、密钥托管、数据保留、访问日志和跨境传输控制。
