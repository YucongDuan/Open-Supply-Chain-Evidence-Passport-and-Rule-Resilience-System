from __future__ import annotations

from collections import deque
from typing import Any

from .store import Store


def trace_lot(store: Store, lot_id: str, max_depth: int = 12) -> dict[str, Any]:
    """Trace a finished lot upstream through event inputs and facilities/organizations."""
    lots: dict[str, dict[str, Any]] = {}
    products: dict[str, dict[str, Any]] = {}
    facilities: dict[str, dict[str, Any]] = {}
    organizations: dict[str, dict[str, Any]] = {}
    events: dict[str, dict[str, Any]] = {}
    edges: list[dict[str, Any]] = []
    queue = deque([(lot_id, 0)])
    visited_lots: set[str] = set()

    all_events = store.all("events")
    producing_events: dict[str, list[dict[str, Any]]] = {}
    for event in all_events:
        for out_lot in event.get("output_lots_json", []):
            producing_events.setdefault(out_lot, []).append(event)

    while queue:
        current, depth = queue.popleft()
        if current in visited_lots or depth > max_depth:
            continue
        visited_lots.add(current)
        lot = store.get("lots", current)
        if not lot:
            continue
        lots[current] = lot
        product = store.get("products", lot["product_id"])
        if product:
            products[product["id"]] = product
            edges.append({"source": product["id"], "target": current, "type": "PRODUCT_HAS_LOT"})
        if lot.get("facility_id"):
            facility = store.get("facilities", lot["facility_id"])
            if facility:
                facilities[facility["id"]] = facility
                edges.append({"source": facility["id"], "target": current, "type": "FACILITY_PRODUCED_LOT"})
                org = store.get("organizations", facility["org_id"])
                if org:
                    organizations[org["id"]] = org
                    edges.append({"source": org["id"], "target": facility["id"], "type": "ORG_OPERATES_FACILITY"})
        for event in producing_events.get(current, []):
            events[event["id"]] = event
            edges.append({"source": event["id"], "target": current, "type": "EVENT_OUTPUT"})
            if event.get("actor_org_id"):
                org = store.get("organizations", event["actor_org_id"])
                if org:
                    organizations[org["id"]] = org
                    edges.append({"source": org["id"], "target": event["id"], "type": "ORG_EXECUTED_EVENT"})
            for input_lot in event.get("input_lots_json", []):
                edges.append({"source": input_lot, "target": event["id"], "type": "EVENT_INPUT"})
                queue.append((input_lot, depth + 1))

    # Include explicit relations among traced organizations/facilities/lots.
    known_ids = set(lots) | set(products) | set(facilities) | set(organizations) | set(events)
    for relation in store.all("relations"):
        if relation["source_id"] in known_ids or relation["target_id"] in known_ids:
            edges.append({
                "source": relation["source_id"],
                "target": relation["target_id"],
                "type": relation["relation_type"],
                "relation_id": relation["id"],
            })
            for endpoint_type, endpoint_id in ((relation["source_type"], relation["source_id"]), (relation["target_type"], relation["target_id"])):
                if endpoint_type == "organization" and endpoint_id not in organizations:
                    obj = store.get("organizations", endpoint_id)
                    if obj:
                        organizations[endpoint_id] = obj
                elif endpoint_type == "facility" and endpoint_id not in facilities:
                    obj = store.get("facilities", endpoint_id)
                    if obj:
                        facilities[endpoint_id] = obj

    return {
        "root_lot": lot_id,
        "lots": list(lots.values()),
        "products": list(products.values()),
        "facilities": list(facilities.values()),
        "organizations": list(organizations.values()),
        "events": list(events.values()),
        "edges": edges,
        "depth_limit": max_depth,
    }


def organization_paths(trace: dict[str, Any], root_lot: str) -> dict[str, list[str]]:
    """Return shortest directed paths from upstream organizations to the root lot."""
    reverse: dict[str, list[str]] = {}
    for edge in trace.get("edges", []):
        reverse.setdefault(edge["target"], []).append(edge["source"])
    # We need paths from org to root. Build forward adjacency.
    forward: dict[str, list[str]] = {}
    for edge in trace.get("edges", []):
        forward.setdefault(edge["source"], []).append(edge["target"])
    org_ids = {o["id"] for o in trace.get("organizations", [])}
    paths: dict[str, list[str]] = {}
    for org_id in org_ids:
        queue = deque([(org_id, [org_id])])
        visited = {org_id}
        while queue:
            node, path = queue.popleft()
            if node == root_lot:
                paths[org_id] = path
                break
            for nxt in forward.get(node, []):
                if nxt not in visited:
                    visited.add(nxt)
                    queue.append((nxt, path + [nxt]))
    return paths


def mass_balance_checks(trace: dict[str, Any], tolerance: float = 0.02) -> list[dict[str, Any]]:
    checks = []
    lots = {l["id"]: l for l in trace.get("lots", [])}
    for event in trace.get("events", []):
        if event["event_type"] != "TransformationEvent":
            continue
        q = event.get("quantities_json", {})
        by_unit: dict[str, dict[str, float]] = {}
        for direction, lot_ids in (("input", event.get("input_lots_json", [])), ("output", event.get("output_lots_json", []))):
            for lot_id in lot_ids:
                lot = lots.get(lot_id, {})
                unit = lot.get("unit") or "unknown"
                by_unit.setdefault(unit, {"input": 0.0, "output": 0.0})
                by_unit[unit][direction] += float(q.get(lot_id, lot.get("quantity") or 0.0))
        for unit, totals in sorted(by_unit.items()):
            input_total = totals["input"]
            output_total = totals["output"]
            if input_total <= 0 and output_total > 0:
                status = "OUTPUT_WITHOUT_INPUT_REVIEW"
            elif output_total <= input_total * (1 + tolerance):
                status = "BALANCED_OR_LOSS"
            else:
                status = "OUTPUT_EXCEEDS_INPUT_REVIEW"
            checks.append({
                "event_id": event["id"],
                "unit": unit,
                "input_total": round(input_total, 6),
                "output_total": round(output_total, 6),
                "tolerance": tolerance,
                "status": status,
            })
    return checks
