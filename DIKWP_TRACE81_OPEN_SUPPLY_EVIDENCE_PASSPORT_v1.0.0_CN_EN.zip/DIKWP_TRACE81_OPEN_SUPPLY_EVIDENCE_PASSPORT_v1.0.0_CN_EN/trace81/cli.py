from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from . import __version__
from .crypto import keygen, sign_document, verify_document
from .demo import create_demo
from .evaluate import evaluate_case
from .exports import build_dossier, build_passport, export_epcis
from .graph import trace_lot
from .rulepacks import diff_rulepacks, load_rulepack, rulepack_summary
from .screening import match_entity
from .store import Store
from .util import dump_json, load_json


def _default_rulepack() -> str:
    return "builtin:uflpa_us_2026-08-03"


def _print(value):
    print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="trace81", description="Open supply-chain evidence passport and rule-resilience system")
    p.add_argument("--version", action="version", version=f"TRACE81 {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("init", help="Initialize an empty database")
    s.add_argument("--db", required=True)

    s = sub.add_parser("demo", help="Create deterministic fictional demo data")
    s.add_argument("--db", required=True)
    s.add_argument("--evidence-dir", required=True)

    s = sub.add_parser("summary", help="Summarize a database")
    s.add_argument("--db", required=True)

    s = sub.add_parser("trace", help="Trace a product lot upstream")
    s.add_argument("--db", required=True)
    s.add_argument("--lot", required=True)
    s.add_argument("--depth", type=int, default=12)
    s.add_argument("--out")

    s = sub.add_parser("screen", help="Screen a name against a rule-pack snapshot")
    s.add_argument("--name", required=True)
    s.add_argument("--alias", action="append", default=[])
    s.add_argument("--rulepack", default=_default_rulepack())

    s = sub.add_parser("evaluate", help="Evaluate evidence readiness for a case")
    s.add_argument("--db", required=True)
    s.add_argument("--case", required=True)
    s.add_argument("--rulepack", default=_default_rulepack())
    s.add_argument("--out")

    s = sub.add_parser("passport", help="Build a supply evidence passport")
    s.add_argument("--db", required=True)
    s.add_argument("--lot", required=True)
    s.add_argument("--view", choices=["public", "assurance"], default="assurance")
    s.add_argument("--out", required=True)

    s = sub.add_parser("epcis", help="Export GS1 EPCIS 2.0-style events")
    s.add_argument("--db", required=True)
    s.add_argument("--lot", required=True)
    s.add_argument("--out", required=True)

    s = sub.add_parser("dossier", help="Build a portable evidence dossier ZIP")
    s.add_argument("--db", required=True)
    s.add_argument("--case", required=True)
    s.add_argument("--rulepack", default=_default_rulepack())
    s.add_argument("--out", required=True)

    s = sub.add_parser("verify-ledger", help="Verify the append-only audit hash chain")
    s.add_argument("--db", required=True)

    s = sub.add_parser("rulepack", help="Inspect a rule pack")
    s.add_argument("--path", default=_default_rulepack())

    s = sub.add_parser("rulepack-diff", help="Compare two rule-pack snapshots")
    s.add_argument("--old", required=True)
    s.add_argument("--new", required=True)
    s.add_argument("--out")

    s = sub.add_parser("keygen", help="Generate optional Ed25519 keys")
    s.add_argument("--private", required=True)
    s.add_argument("--public", required=True)

    s = sub.add_parser("sign", help="Sign a passport or credential JSON")
    s.add_argument("--input", required=True)
    s.add_argument("--private", required=True)
    s.add_argument("--verification-method", required=True)
    s.add_argument("--out", required=True)

    s = sub.add_parser("verify-signature", help="Verify a signed JSON document")
    s.add_argument("--input", required=True)
    s.add_argument("--public", required=True)

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "init":
        with Store(args.db) as store:
            store.set_meta("system", {"name": "DIKWP-MESH8.1 TRACE81", "version": __version__})
        _print({"status": "initialized", "db": args.db})
        return 0
    if args.command == "demo":
        with Store(args.db) as store:
            create_demo(store, args.evidence_dir)
            result = {"status": "demo-created", "db": args.db, "audit": store.verify_audit()}
        _print(result)
        return 0
    if args.command == "summary":
        with Store(args.db) as store:
            result = {table: len(store.all(table)) for table in ["organizations", "facilities", "products", "lots", "events", "relations", "shipments", "evidence", "cases"]}
            result["audit"] = store.verify_audit()
        _print(result)
        return 0
    if args.command == "trace":
        with Store(args.db) as store:
            result = trace_lot(store, args.lot, args.depth)
        if args.out:
            dump_json(args.out, result)
        else:
            _print(result)
        return 0
    if args.command == "screen":
        rp = load_rulepack(args.rulepack)
        entries = rp.get("entity_list_snapshot", {}).get("entries", [])
        _print({"name": args.name, "matches": match_entity(args.name, args.alias, entries), "boundary": "Review signal only; not an identity or legal determination."})
        return 0
    if args.command == "evaluate":
        with Store(args.db) as store:
            result = evaluate_case(store, args.case, args.rulepack)
        if args.out:
            dump_json(args.out, result)
        else:
            _print(result)
        return 0
    if args.command == "passport":
        with Store(args.db) as store:
            result = build_passport(store, args.lot, view=args.view)
        dump_json(args.out, result)
        _print({"status": "written", "path": args.out, "digest": result["trace81Digest"]})
        return 0
    if args.command == "epcis":
        with Store(args.db) as store:
            result = export_epcis(store, args.lot)
        dump_json(args.out, result)
        _print({"status": "written", "path": args.out, "events": len(result["epcisBody"]["eventList"])})
        return 0
    if args.command == "dossier":
        with Store(args.db) as store:
            path = build_dossier(store, args.case, args.rulepack, args.out)
        _print({"status": "written", "path": str(path)})
        return 0
    if args.command == "verify-ledger":
        with Store(args.db) as store:
            _print(store.verify_audit())
        return 0
    if args.command == "rulepack":
        _print(rulepack_summary(load_rulepack(args.path)))
        return 0
    if args.command == "rulepack-diff":
        result = diff_rulepacks(args.old, args.new)
        if args.out:
            dump_json(args.out, result)
        else:
            _print(result)
        return 0
    if args.command == "keygen":
        keygen(args.private, args.public)
        _print({"status": "keys-generated", "private": args.private, "public": args.public})
        return 0
    if args.command == "sign":
        signed = sign_document(load_json(args.input), args.private, args.verification_method)
        dump_json(args.out, signed)
        _print({"status": "signed", "out": args.out})
        return 0
    if args.command == "verify-signature":
        valid = verify_document(load_json(args.input), args.public)
        _print({"valid": valid})
        return 0 if valid else 2
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
