# SECP 0.1 草案｜Supply Evidence Continuity Protocol Draft

**状态 / Status:** 开放讨论稿（Open discussion draft）  
**项目 / Project:** DIKWP-MESH8.1 TRACE81（溯证81）  
**提出 / Proposed by:** Yucong Duan（段玉聪）  
**日期 / Date:** 2026-08-12

## 1. 目的｜Purpose

SECP 不是法律认证规则，也不判断强迫劳动、制裁身份、货物可入境性或企业合规。它规定供应链证据在跨企业、跨系统、跨规则版本和跨披露边界迁移时，最低限度应如何保持来源、差异、阶段性整体、适用规则与生成过程。

SECP is not a legal certification scheme. It does not determine forced-labour facts, sanctions identity, admissibility, or legal compliance. It specifies minimum behaviours for preserving provenance, differences, provisional completeness, governing context, and transformation history when supply-chain evidence moves across organisations, systems, rule versions, and disclosure boundaries.

## 2. 五类原生责任｜Five native responsibilities

- **D — 来源保持 / provenance continuity:** 文件、事件、批次、主体和规则快照必须保留稳定标识、来源引用及摘要。
- **I — 差异不删除 / difference preservation:** 缺失、冲突、过期、名称不确定、数量不平衡和版本差异必须显式保存，不得被总分吞并。
- **K — 阶段性整体 / provisional whole:** 护照只覆盖声明的产品、批次、时段、法域、规则版本和披露视图，不得冒充终局合规证明。
- **W — 适用世界 / governing context:** 市场、法域、采购要求、证据阈值、保密边界和评价目的必须版本化。
- **P — 可回放过程 / replayable process:** 上溯、筛查、评估、补证、脱敏、签名、导出、复核和回滚步骤必须可追踪。

## 3. 最低数据行为｜Minimum data behaviours

一个声称符合 SECP 0.1 数据行为的实现 **MUST**：

1. 为组织、设施、产品、批次、事件、关系、运输、证据、规则包和案件提供稳定标识；
2. 对每份证据保存摘要、来源、采集时间、有效期、保密级别和持有方；
3. 记录产品批次的上游关系，并保存转换、聚合、拆分与运输事件；
4. 将名单名称匹配输出限定为复核信号，不得自动宣告法律身份；
5. 将缺失、过期、冲突和质量平衡异常作为独立差异记录；
6. 在每次评估中冻结所用规则包的标识、版本、日期、来源和适用范围；
7. 区分公共护照与鉴证护照，并使脱敏过程可说明；
8. 为可移交案卷生成文件清单和摘要账本；
9. 公开系统结论边界；
10. 允许重新执行评估并比较版本差异。

An implementation claiming SECP 0.1 data-behaviour conformance **MUST** implement the equivalent behaviours above. Conformance concerns data and interface behaviour only; it is not certification of the underlying company, product, labour conditions, or legal outcome.

## 4. 证据状态｜Evidence states

实现 **SHOULD** 至少区分：

- `PRESENT`：所需证据存在且在声明时点内有效；
- `STALE`：证据存在但已超过声明有效期；
- `MISSING`：所需证据未提供；
- `PROCESS_REVIEW`：需要人工、律师、审计或业务流程复核；
- `CONFLICT`：两个或多个来源不能无损合并；
- `IDENTITY_REVIEW_REQUIRED`：名称或别名相似，但法律身份尚未判定。

## 5. 规则包治理｜Rule-pack governance

每个规则包 **MUST** 含有：标识、版本、生效日期、快照日期、主管机构、来源链接、范围说明、法律边界、要求清单及其稳定标识。增量快照不得被描述为完整清单。规则包更新不得追溯性改写既有案件；新评估应产生新版本。

## 6. 护照视图｜Passport views

- **公共视图 / Public view:** 只披露授权公开的路径、摘要与边界；
- **鉴证视图 / Assurance view:** 向经授权的进口商、律师、审计或监管复核方提供更完整证据引用；
- **内部视图 / Internal view:** 可含商业敏感原始文件，但不得因脱敏而修改其摘要或来源关系。

任何视图变化都 **MUST** 形成新的视图摘要，而非覆盖原护照。

## 7. 一致性声明｜Conformance claim

推荐声明：

> “This implementation conforms to TRACE81 SECP 0.1 data-behaviour requirements for the declared profile. The claim does not certify legal compliance or underlying factual truth.”

推荐中文：

> “本实现符合 TRACE81 SECP 0.1 所声明配置的数据行为要求；该声明不构成法律合规认证，也不证明底层事实为真。”

## 8. 开放治理｜Open governance

SECP 建议采用公开议题、版本化草案、可复现测试和多方评审。律师、进口商、审计机构、GS1 社群、制造企业、银行保险和研究机构可以提交问题与修订建议。项目名称、官方一致性标志与签名密钥可由治理主体管理，以防止第三方借开源代码冒充官方认证。
