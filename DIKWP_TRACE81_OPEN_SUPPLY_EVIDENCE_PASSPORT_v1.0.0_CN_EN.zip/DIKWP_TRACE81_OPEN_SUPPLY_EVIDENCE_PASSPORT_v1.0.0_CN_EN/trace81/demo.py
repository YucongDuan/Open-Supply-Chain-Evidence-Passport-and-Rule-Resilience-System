from __future__ import annotations

from pathlib import Path

from .store import Store
from .util import sha256_file, utc_now


def _write_evidence(root: Path, name: str, text: str) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    path = root / name
    path.write_text(text.strip() + "\n", encoding="utf-8")
    return path


def create_demo(store: Store, evidence_root: str | Path) -> None:
    root = Path(evidence_root)
    store.set_meta("system", {"name": "DIKWP-MESH8.1 TRACE81", "version": "1.0.0"})
    organizations = [
        {"id": "ORG-BRAND", "legal_name": "Helio Harvest Foods Co., Ltd.", "aliases_json": ["Helio Harvest"], "country": "CN", "region": "Anhui", "address": "Demo address", "registration_id": "DEMO-91340001", "metadata_json": {"role": "brand_exporter", "fictional": True}},
        {"id": "ORG-FARM", "legal_name": "SunRiver Agricultural Cooperative", "aliases_json": ["SunRiver Co-op"], "country": "CN", "region": "Gansu", "address": "Demo address", "registration_id": "DEMO-62010002", "metadata_json": {"role": "raw_material_supplier", "fictional": True}},
        {"id": "ORG-OIL", "legal_name": "ClearOil Processing Ltd.", "aliases_json": [], "country": "CN", "region": "Shandong", "address": "Demo address", "registration_id": "DEMO-37020003", "metadata_json": {"role": "ingredient_processor", "fictional": True}},
        {"id": "ORG-PACK", "legal_name": "OceanBridge Packaging Co., Ltd.", "aliases_json": [], "country": "CN", "region": "Jiangsu", "address": "Demo address", "registration_id": "DEMO-32010004", "metadata_json": {"role": "packaging_supplier", "fictional": True}},
        {"id": "ORG-LOG", "legal_name": "HarborGate Logistics Ltd.", "aliases_json": [], "country": "CN", "region": "Shanghai", "address": "Demo address", "registration_id": "DEMO-31010005", "metadata_json": {"role": "logistics", "fictional": True}},
        {"id": "ORG-IMPORT", "legal_name": "NorthStar Import Services LLC", "aliases_json": [], "country": "US", "region": "California", "address": "Demo address", "registration_id": "DEMO-US-CA-06", "metadata_json": {"role": "importer", "fictional": True}},
        {"id": "ORG-DEMO-RESTRICTED", "legal_name": "Demo Restricted Fiber Company", "aliases_json": ["DR Fiber"], "country": "XZ", "region": "Demonstration Region", "address": "Fictional", "registration_id": "DEMO-ONLY-007", "metadata_json": {"role": "fictional_watchlist_demo", "fictional": True}},
    ]
    store.insert_many("organizations", organizations, actor="demo")

    facilities = [
        {"id": "FAC-FARM", "org_id": "ORG-FARM", "name": "SunRiver Farm Cluster", "country": "CN", "region": "Gansu", "address": "Demo", "latitude": 36.061, "longitude": 103.834, "metadata_json": {"fictional": True}},
        {"id": "FAC-OIL", "org_id": "ORG-OIL", "name": "ClearOil Plant", "country": "CN", "region": "Shandong", "address": "Demo", "latitude": 36.668, "longitude": 117.020, "metadata_json": {"fictional": True}},
        {"id": "FAC-PACK", "org_id": "ORG-PACK", "name": "OceanBridge Packaging Plant", "country": "CN", "region": "Jiangsu", "address": "Demo", "latitude": 32.060, "longitude": 118.796, "metadata_json": {"fictional": True}},
        {"id": "FAC-BRAND", "org_id": "ORG-BRAND", "name": "Helio Roasting and Packing Facility", "country": "CN", "region": "Anhui", "address": "Demo", "latitude": 31.861, "longitude": 117.285, "metadata_json": {"fictional": True}},
    ]
    store.insert_many("facilities", facilities, actor="demo")

    products = [
        {"id": "PROD-SEED", "name": "Raw sunflower seed", "gtin": None, "sector": "agriculture", "description": "Fictional raw material", "metadata_json": {"hs_code": "1206", "fictional": True}},
        {"id": "PROD-OIL", "name": "Food-grade sunflower oil", "gtin": None, "sector": "food_ingredient", "description": "Fictional ingredient", "metadata_json": {"fictional": True}},
        {"id": "PROD-POUCH", "name": "Food contact pouch", "gtin": None, "sector": "packaging", "description": "Fictional packaging", "metadata_json": {"fictional": True}},
        {"id": "PROD-SNACK", "name": "Roasted sunflower seed snack", "gtin": "09506000123456", "sector": "food", "description": "Fictional finished consumer product", "metadata_json": {"brand": "Helio Harvest", "fictional": True}},
        {"id": "PROD-FIBER", "name": "Demo textile fiber", "gtin": None, "sector": "textile", "description": "Fictional restricted-path demonstration", "metadata_json": {"fictional": True}},
    ]
    store.insert_many("products", products, actor="demo")

    lots = [
        {"id": "LOT-SEED-001", "product_id": "PROD-SEED", "facility_id": "FAC-FARM", "quantity": 10000, "unit": "kg", "produced_at": "2026-06-15T08:00:00Z", "metadata_json": {"harvest_season": "2026", "fictional": True}},
        {"id": "LOT-OIL-001", "product_id": "PROD-OIL", "facility_id": "FAC-OIL", "quantity": 650, "unit": "kg", "produced_at": "2026-06-20T08:00:00Z", "metadata_json": {"fictional": True}},
        {"id": "LOT-POUCH-001", "product_id": "PROD-POUCH", "facility_id": "FAC-PACK", "quantity": 20000, "unit": "each", "produced_at": "2026-06-22T08:00:00Z", "metadata_json": {"fictional": True}},
        {"id": "LOT-SNACK-001", "product_id": "PROD-SNACK", "facility_id": "FAC-BRAND", "quantity": 9200, "unit": "kg", "produced_at": "2026-07-01T08:00:00Z", "metadata_json": {"batch": "HH-20260701-A", "fictional": True}},
        {"id": "LOT-FIBER-001", "product_id": "PROD-FIBER", "facility_id": "FAC-PACK", "quantity": 1000, "unit": "kg", "produced_at": "2026-07-02T08:00:00Z", "metadata_json": {"fictional": True, "demo_only": True}},
        {"id": "LOT-BAG-001", "product_id": "PROD-POUCH", "facility_id": "FAC-PACK", "quantity": 9500, "unit": "each", "produced_at": "2026-07-03T08:00:00Z", "metadata_json": {"fictional": True, "demo_only": True}},
    ]
    store.insert_many("lots", lots, actor="demo")

    events = [
        {"id": "EV-HARVEST", "event_type": "ObjectEvent", "event_time": "2026-06-15T08:00:00Z", "actor_org_id": "ORG-FARM", "facility_id": "FAC-FARM", "input_lots_json": [], "output_lots_json": ["LOT-SEED-001"], "quantities_json": {"LOT-SEED-001": 10000}, "biz_step": "urn:epcglobal:cbv:bizstep:commissioning", "disposition": "urn:epcglobal:cbv:disp:active", "metadata_json": {"fictional": True}},
        {"id": "EV-OIL", "event_type": "ObjectEvent", "event_time": "2026-06-20T08:00:00Z", "actor_org_id": "ORG-OIL", "facility_id": "FAC-OIL", "input_lots_json": [], "output_lots_json": ["LOT-OIL-001"], "quantities_json": {"LOT-OIL-001": 650}, "biz_step": "urn:epcglobal:cbv:bizstep:commissioning", "disposition": "urn:epcglobal:cbv:disp:active", "metadata_json": {"fictional": True}},
        {"id": "EV-POUCH", "event_type": "ObjectEvent", "event_time": "2026-06-22T08:00:00Z", "actor_org_id": "ORG-PACK", "facility_id": "FAC-PACK", "input_lots_json": [], "output_lots_json": ["LOT-POUCH-001"], "quantities_json": {"LOT-POUCH-001": 20000}, "biz_step": "urn:epcglobal:cbv:bizstep:commissioning", "disposition": "urn:epcglobal:cbv:disp:active", "metadata_json": {"fictional": True}},
        {"id": "EV-ROAST", "event_type": "TransformationEvent", "event_time": "2026-07-01T08:00:00Z", "actor_org_id": "ORG-BRAND", "facility_id": "FAC-BRAND", "input_lots_json": ["LOT-SEED-001", "LOT-OIL-001", "LOT-POUCH-001"], "output_lots_json": ["LOT-SNACK-001"], "quantities_json": {"LOT-SEED-001": 9000, "LOT-OIL-001": 300, "LOT-POUCH-001": 9500, "LOT-SNACK-001": 9200}, "biz_step": "urn:epcglobal:cbv:bizstep:commissioning", "disposition": "urn:epcglobal:cbv:disp:active", "metadata_json": {"mass_balance_basis": "food mass excludes packaging unit count", "fictional": True}},
        {"id": "EV-DEMO-FIBER", "event_type": "ObjectEvent", "event_time": "2026-07-02T08:00:00Z", "actor_org_id": "ORG-DEMO-RESTRICTED", "facility_id": "FAC-PACK", "input_lots_json": [], "output_lots_json": ["LOT-FIBER-001"], "quantities_json": {"LOT-FIBER-001": 1000}, "biz_step": "urn:epcglobal:cbv:bizstep:commissioning", "disposition": "urn:epcglobal:cbv:disp:active", "metadata_json": {"fictional": True, "demo_only": True}},
        {"id": "EV-DEMO-BAG", "event_type": "TransformationEvent", "event_time": "2026-07-03T08:00:00Z", "actor_org_id": "ORG-PACK", "facility_id": "FAC-PACK", "input_lots_json": ["LOT-FIBER-001"], "output_lots_json": ["LOT-BAG-001"], "quantities_json": {"LOT-FIBER-001": 1000, "LOT-BAG-001": 950}, "biz_step": "urn:epcglobal:cbv:bizstep:commissioning", "disposition": "urn:epcglobal:cbv:disp:active", "metadata_json": {"fictional": True, "demo_only": True}},
    ]
    store.insert_many("events", events, actor="demo")

    relations = [
        {"id": "REL-FARM-BRAND", "source_type": "organization", "source_id": "ORG-FARM", "target_type": "organization", "target_id": "ORG-BRAND", "relation_type": "SUPPLIES", "valid_from": "2026-01-01", "valid_to": None, "metadata_json": {"commodity": "sunflower seeds", "fictional": True}},
        {"id": "REL-OIL-BRAND", "source_type": "organization", "source_id": "ORG-OIL", "target_type": "organization", "target_id": "ORG-BRAND", "relation_type": "SUPPLIES", "valid_from": "2026-01-01", "valid_to": None, "metadata_json": {"commodity": "oil", "fictional": True}},
        {"id": "REL-PACK-BRAND", "source_type": "organization", "source_id": "ORG-PACK", "target_type": "organization", "target_id": "ORG-BRAND", "relation_type": "SUPPLIES", "valid_from": "2026-01-01", "valid_to": None, "metadata_json": {"commodity": "packaging", "fictional": True}},
    ]
    store.insert_many("relations", relations, actor="demo")

    shipments = [
        {"id": "SHIP-SNACK-US-001", "product_lot_id": "LOT-SNACK-001", "exporter_org_id": "ORG-BRAND", "importer_org_id": "ORG-IMPORT", "origin_country": "CN", "destination_country": "US", "departure_date": "2026-07-10", "arrival_date": "2026-07-28", "entry_number": "DEMO-ENTRY-001", "metadata_json": {"port": "Los Angeles", "fictional": True}},
        {"id": "SHIP-BAG-US-001", "product_lot_id": "LOT-BAG-001", "exporter_org_id": "ORG-PACK", "importer_org_id": "ORG-IMPORT", "origin_country": "CN", "destination_country": "US", "departure_date": "2026-07-11", "arrival_date": "2026-07-29", "entry_number": "DEMO-ENTRY-002", "metadata_json": {"port": "Los Angeles", "fictional": True, "demo_only": True}},
    ]
    store.insert_many("shipments", shipments, actor="demo")

    cases = [
        {"id": "CASE-SNACK-US", "name": "Fictional sunflower snack U.S. evidence-readiness review", "shipment_id": "SHIP-SNACK-US-001", "market": "US", "rulepack_id": "US-UFLPA-2026-08-03", "status": "OPEN", "created_at": utc_now(), "metadata_json": {"fictional": True}},
        {"id": "CASE-DEMO-MATCH", "name": "Fictional indirect watchlist-path demonstration", "shipment_id": "SHIP-BAG-US-001", "market": "US", "rulepack_id": "DEMO-WATCHLIST-1", "status": "OPEN", "created_at": utc_now(), "metadata_json": {"fictional": True, "demo_only": True}},
    ]
    store.insert_many("cases", cases, actor="demo")

    evidence_specs = [
        ("EV-PO-001", "organization", "ORG-FARM", "PURCHASE_ORDER", "Purchase order for sunflower seeds", "Helio Harvest procurement", "2026-05-20", "2027-05-20", "po_seed_001.txt", "PO references supplier, commodity, quantity, and lot linkage."),
        ("EV-INVOICE-001", "organization", "ORG-FARM", "COMMERCIAL_INVOICE", "Commercial invoice for seed purchase", "SunRiver Cooperative", "2026-06-16", None, "invoice_seed_001.txt", "Invoice issued in ordinary course of business."),
        ("EV-ORIGIN-001", "lot", "LOT-SEED-001", "ORIGIN_RECORD", "Farm and harvest origin record", "SunRiver Cooperative", "2026-06-15", "2027-06-15", "origin_seed_001.txt", "Origin record identifies fictional farm cluster and harvest date."),
        ("EV-PROD-001", "event", "EV-ROAST", "PRODUCTION_RECORD", "Roasting and packing production record", "Helio Harvest operations", "2026-07-01", None, "production_001.txt", "Production record links input and output lots."),
        ("EV-TRANS-001", "shipment", "SHIP-SNACK-US-001", "TRANSPORT_RECORD", "Bill of lading and packing list summary", "HarborGate Logistics", "2026-07-10", None, "transport_001.txt", "Shipment record links finished lot to demo entry."),
        ("EV-PAY-001", "organization", "ORG-FARM", "PAYMENT_RECORD", "Payment confirmation", "Demo Bank", "2026-06-25", None, "payment_001.txt", "Payment record supports commercial transaction."),
        ("EV-LABOR-001", "facility", "FAC-FARM", "LABOR_DUE_DILIGENCE", "Worker and recruitment due-diligence summary", "Independent Demo Auditor", "2025-06-01", "2026-06-01", "labor_audit_expired.txt", "Expired on purpose to demonstrate a stale evidence signal."),
        ("EV-CONTROL-001", "organization", "ORG-BRAND", "SUPPLY_CHAIN_CONTROL", "Supplier onboarding and escalation controls", "Helio Harvest compliance", "2026-01-15", "2027-01-15", "controls_001.txt", "Documents supplier onboarding, escalation, remediation, and record retention."),
        ("EV-RECON-001", "event", "EV-ROAST", "RECONCILIATION_RECORD", "Lot-level reconciliation note", "Helio Harvest finance", "2026-07-02", None, "reconciliation_001.txt", "Reconciles food mass separately from packaging units."),
        ("EV-TRANSLATION-001", "case", "CASE-SNACK-US", "ENGLISH_TRANSLATION", "Certified English translation index", "Demo Translation Service", "2026-07-20", "2027-07-20", "translation_index.txt", "Indexes translated source documents."),
        ("EV-MAP-001", "case", "CASE-SNACK-US", "SUPPLY_CHAIN_MAP", "Product-specific supply-chain map", "Helio Harvest compliance", "2026-07-19", "2027-07-19", "supply_chain_map.txt", "Identifies the fictional product lot, facilities, suppliers, transformations, and shipment links."),
        ("EV-INTEGRITY-001", "case", "CASE-SNACK-US", "INTEGRITY_ATTESTATION", "Evidence manifest integrity attestation", "Helio Harvest compliance", "2026-07-21", "2027-07-21", "integrity_attestation.txt", "Declares that the packet manifest hashes are generated from the attached demonstration files; factual authenticity remains separately reviewable."),
        ("EV-PLAYBOOK-001", "case", "CASE-SNACK-US", "RESPONSE_PLAYBOOK", "Authority-response and escalation playbook", "Helio Harvest legal and compliance", "2026-07-18", "2027-07-18", "response_playbook.txt", "Assigns importer, counsel, operations, supplier, translation, and evidence-owner responsibilities for a time-bound response."),
    ]
    for evidence_id, subject_type, subject_id, evidence_type, title, issuer, issued_at, valid_until, filename, text in evidence_specs:
        path = _write_evidence(root, filename, text)
        store.upsert("evidence", {
            "id": evidence_id,
            "subject_type": subject_type,
            "subject_id": subject_id,
            "evidence_type": evidence_type,
            "title": title,
            "issuer": issuer,
            "issued_at": issued_at,
            "valid_until": valid_until,
            "file_path": str(path),
            "file_hash": sha256_file(path),
            "source_uri": None,
            "confidentiality": "restricted" if evidence_type not in {"ORIGIN_RECORD"} else "public",
            "claims_json": [text],
            "metadata_json": {"fictional": True},
        }, actor="demo")
