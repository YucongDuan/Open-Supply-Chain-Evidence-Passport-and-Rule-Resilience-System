from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .graph import mass_balance_checks, organization_paths, trace_lot
from .rulepacks import load_rulepack
from .screening import match_entity
from .store import Store
from .util import utc_now


def _parse_date(value: str | None):
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed
    except ValueError:
        return None


def _remediation_tasks(unresolved: list[dict[str, Any]]) -> list[dict[str, Any]]:
    tasks: list[dict[str, Any]] = []
    for idx, item in enumerate(unresolved, start=1):
        kind = item["kind"]
        severity = item["severity"]
        if kind == "ENTITY_MATCH_REVIEW":
            action = "Resolve legal-entity identity with registration identifiers, ownership records, addresses, aliases, and counsel review; do not rely on name similarity alone."
            owner = "Legal / supplier master-data owner"
        elif kind == "EVIDENCE_GAP":
            status = item["detail"]["status"]
            action = (
                "Renew and independently validate the stale evidence, preserve the prior version, and link the replacement to the same subject."
                if status == "STALE"
                else "Request the missing evidence from the accountable supplier or internal owner, record refusal or non-response, and keep the gap visible."
            )
            owner = "Evidence owner / supplier assurance"
        else:
            action = "Reconcile quantities by unit and transformation basis; preserve yield, loss, scrap, co-product, and packaging assumptions as explicit records."
            owner = "Operations / finance / quality"
        tasks.append({
            "id": f"TASK-{idx:03d}",
            "priority": "P0" if severity in {"HIGH", "MISSING"} else "P1",
            "owner": owner,
            "subject": item["subject"],
            "action": action,
            "source_signal": kind,
            "closure_boundary": "Completing this task closes an evidence-process gap only; it does not create a legal compliance determination.",
        })
    return tasks


def evaluate_case(store: Store, case_id: str, rulepack_path: str | Path) -> dict[str, Any]:
    case = store.get("cases", case_id)
    if not case:
        raise KeyError(f"Unknown case: {case_id}")
    shipment = store.get("shipments", case["shipment_id"])
    if not shipment:
        raise KeyError(f"Case shipment missing: {case['shipment_id']}")
    rulepack = load_rulepack(rulepack_path)
    trace = trace_lot(store, shipment["product_lot_id"])
    org_paths = organization_paths(trace, shipment["product_lot_id"])
    entries = rulepack.get("entity_list_snapshot", {}).get("entries", [])

    screening = []
    for org in trace["organizations"]:
        matches = match_entity(org["legal_name"], org.get("aliases_json", []), entries)
        for match in matches:
            match["organization_id"] = org["id"]
            match["organization_name"] = org["legal_name"]
            match["path_to_product_lot"] = org_paths.get(org["id"], [])
            screening.append(match)

    evidence = store.all("evidence")
    subject_ids = {
        *(o["id"] for o in trace["organizations"]),
        *(f["id"] for f in trace["facilities"]),
        *(p["id"] for p in trace["products"]),
        *(l["id"] for l in trace["lots"]),
        *(e["id"] for e in trace["events"]),
        shipment["id"],
        case["id"],
    }
    relevant_evidence = [e for e in evidence if e["subject_id"] in subject_ids]
    by_type: dict[str, list[dict[str, Any]]] = defaultdict(list)
    now = datetime.now(timezone.utc)
    for item in relevant_evidence:
        expiry = _parse_date(item.get("valid_until"))
        item = dict(item)
        item["freshness"] = "EXPIRED" if expiry and expiry < now else "CURRENT_OR_UNDATED"
        by_type[item["evidence_type"]].append(item)

    coverage = []
    for req in rulepack.get("requirements", []):
        evidence_types = req.get("evidence_types", [])
        found = [item for et in evidence_types for item in by_type.get(et, [])]
        current = [item for item in found if item["freshness"] != "EXPIRED"]
        if not evidence_types:
            status = "PROCESS_REVIEW"
        elif current:
            status = "PRESENT"
        elif found:
            status = "STALE"
        else:
            status = "MISSING"
        coverage.append({
            "requirement_id": req["id"],
            "title": req["title"],
            "status": status,
            "evidence_types": evidence_types,
            "evidence_ids": [i["id"] for i in found],
            "notes": req.get("notes", ""),
        })

    mass_balance = mass_balance_checks(trace)
    unresolved = []
    for item in screening:
        unresolved.append({
            "kind": "ENTITY_MATCH_REVIEW",
            "severity": "HIGH" if item["status"] == "EXACT_NAME_OR_ALIAS_MATCH" else "REVIEW",
            "subject": item["organization_id"],
            "detail": item,
        })
    for item in coverage:
        if item["status"] in {"MISSING", "STALE"}:
            unresolved.append({
                "kind": "EVIDENCE_GAP",
                "severity": "MISSING" if item["status"] == "MISSING" else "STALE",
                "subject": item["requirement_id"],
                "detail": item,
            })
    for item in mass_balance:
        if item["status"] != "BALANCED_OR_LOSS":
            unresolved.append({"kind": "MASS_BALANCE_REVIEW", "severity": "REVIEW", "subject": item["event_id"], "detail": item})

    audit = store.verify_audit()
    visibility = {
        "organizations": len(trace["organizations"]),
        "facilities": len(trace["facilities"]),
        "lots": len(trace["lots"]),
        "events": len(trace["events"]),
        "edges": len(trace["edges"]),
    }
    statuses = defaultdict(int)
    for item in coverage:
        statuses[item["status"]] += 1

    # DIKWP records the structure of the review. It is not a legal compliance result.
    dikwp = {
        "D": {
            "closed": bool(trace["events"]) and audit["valid"],
            "meaning": "Source events and evidence integrity are recorded and replayable.",
        },
        "I": {
            "closed": True,
            "meaning": "Differences, ambiguities, gaps, and conflicts remain explicitly visible.",
            "open_items": len(unresolved),
        },
        "K": {
            "closed": bool(trace["organizations"]) and bool(trace["lots"]),
            "meaning": "A current, stage-bounded supply passport snapshot covers the traced records.",
        },
        "W": {
            "closed": rulepack["id"] == case["rulepack_id"],
            "meaning": "The market and rule-pack version are explicit, not hidden as universal truth.",
        },
        "P": {
            "closed": True,
            "meaning": "Trace, screen, review, export, remediate, and replay procedures are available.",
        },
    }
    vector = "".join("1" if dikwp[k]["closed"] else "0" for k in "DIKWP")
    remediation_tasks = _remediation_tasks(unresolved)
    if screening:
        evidence_state = "IDENTITY_REVIEW_REQUIRED"
    elif any(x["status"] == "MISSING" for x in coverage):
        evidence_state = "EVIDENCE_GAPS_PRESENT"
    elif any(x["status"] == "STALE" for x in coverage):
        evidence_state = "READY_WITH_STALE_EVIDENCE"
    else:
        evidence_state = "STRUCTURALLY_READY_FOR_HUMAN_REVIEW"

    return {
        "system": "DIKWP-MESH8.1 TRACE81",
        "generated_at": utc_now(),
        "case": case,
        "shipment": shipment,
        "rulepack": {
            "id": rulepack["id"],
            "version": rulepack["version"],
            "effective_date": rulepack["effective_date"],
            "digest": rulepack["digest"],
            "legal_boundary": rulepack["legal_boundary"],
        },
        "trace": trace,
        "visibility": visibility,
        "screening": screening,
        "screening_scope": {
            "snapshot_entries": len(entries),
            "snapshot_note": rulepack.get("entity_list_snapshot", {}).get("scope_note", "Rule-pack snapshot only."),
            "identity_boundary": "Name matching is a review signal. Legal identity requires independent identifiers and human review.",
        },
        "coverage": coverage,
        "coverage_counts": dict(statuses),
        "mass_balance": mass_balance,
        "unresolved_signals": unresolved,
        "remediation_tasks": remediation_tasks,
        "evidence_state": evidence_state,
        "audit": audit,
        "dikwp": dikwp,
        "dikwp_vector": vector,
        "conclusion_boundary": (
            "TRACE81 organizes evidence and preserves unresolved signals. It does not determine legal compliance, "
            "forced-labor facts, admissibility, or entity identity. Those determinations belong to competent authorities, "
            "qualified counsel, auditors, and the relevant parties on the full record."
        ),
    }
