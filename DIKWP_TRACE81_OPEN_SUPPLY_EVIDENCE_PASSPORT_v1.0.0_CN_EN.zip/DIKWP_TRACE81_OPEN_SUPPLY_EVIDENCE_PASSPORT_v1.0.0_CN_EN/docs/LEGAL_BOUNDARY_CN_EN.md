# Legal and evidentiary boundary / 法律与证据边界

## 中文

TRACE81 是证据组织、流程治理和互操作参考实现，不是法律意见、认证机构、海关决定系统或事实裁判器。

- 名称或别名匹配只生成审查信号，不确认实体身份；
- 文件存在不证明文件内容真实；
- 文件摘要只能证明所持文件是否变化，不能证明其事实陈述正确；
- 证据覆盖不等于满足“明确且令人信服”的具体法律标准；
- `11111` 是 D/I/K/W/P 结构可运行，不是“合规”；
- 规则包是有日期的公开资料快照，必须持续更新；
- 产品入境、清单移除、扣留回应、排除或例外申请等事项必须由进口商、合格律师、审计机构和主管机关依据完整个案决定。

TRACE81 不应被用于规避、隐藏、伪造或误导监管审查。系统设计要求保留不利证据、冲突、拒绝提供资料和无法解释的差异。

## English

TRACE81 is an evidence-organization, process-governance, and interoperability reference implementation. It is not legal advice, certification, a customs decision engine, or a fact finder. Name matches are review signals; file hashes do not prove factual truth; structural coverage is not a legal conclusion. The system must not be used to evade, conceal, fabricate, or mislead regulatory review.
