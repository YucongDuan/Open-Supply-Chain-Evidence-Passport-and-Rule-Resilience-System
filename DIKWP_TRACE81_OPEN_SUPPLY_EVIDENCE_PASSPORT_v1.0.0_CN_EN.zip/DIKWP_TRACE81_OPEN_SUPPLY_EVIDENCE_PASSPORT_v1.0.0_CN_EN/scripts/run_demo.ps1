$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root
Remove-Item data/examples/trace81_demo.sqlite -ErrorAction SilentlyContinue
Remove-Item data/examples/evidence -Recurse -Force -ErrorAction SilentlyContinue
New-Item artifacts -ItemType Directory -Force | Out-Null
python -m trace81 demo --db data/examples/trace81_demo.sqlite --evidence-dir data/examples/evidence
python -m trace81 evaluate --db data/examples/trace81_demo.sqlite --case CASE-SNACK-US --rulepack builtin:uflpa_us_2026-08-03 --out artifacts/case_snack_us_evaluation.json
python -m trace81 dossier --db data/examples/trace81_demo.sqlite --case CASE-SNACK-US --rulepack builtin:uflpa_us_2026-08-03 --out artifacts/TRACE81_DOSSIER_CASE-SNACK-US.zip
python -m unittest discover -s tests -v
