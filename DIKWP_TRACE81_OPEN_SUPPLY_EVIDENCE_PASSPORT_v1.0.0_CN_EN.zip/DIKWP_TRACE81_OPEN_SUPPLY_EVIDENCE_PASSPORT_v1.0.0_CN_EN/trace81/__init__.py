"""DIKWP TRACE81 - open supply-chain evidence passport."""

__version__ = "1.0.0"
__author__ = "Yucong Duan"
