# Roadmap / 路线图

## v1.1

- 完整 UFLPA 官方清单同步器（带来源和变更复核）；
- CSV/Excel 导入和 GS1 标识增强；
- 供应商证据请求工作流；
- PostgreSQL 后端适配；
- Dossier 可验证签名与撤销状态。

## v1.5

- ERP/MES/WMS/TMS 连接器 SDK；
- 多租户与字段级授权；
- 规则包签名、批准和回滚；
- 进口商/律师安全协作室；
- 多语言证据索引。

## v2.0

- SECP 开放协议；
- 可插拔实体解析和外部数据供应商接口；
- 行业护照模板；
- DPP、EUDR、CBAM、供应链尽调等规则包生态；
- TRACE81 Conformance 实验室。
