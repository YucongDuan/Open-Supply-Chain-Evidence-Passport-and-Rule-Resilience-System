# TRACE81 Architecture / 系统架构

## 中文

TRACE81 将“供应链”从一张供应商名单改写为五类持续生成记录：

1. **D 来源保持层**：企业、工厂、产品、批次、事件、证据文件和摘要；
2. **I 差异保持层**：缺失、过期、冲突、别名相似、数量异常及无法确认的链路；
3. **K 阶段护照层**：特定批次、特定市场、特定日期与特定规则包下的当前完整快照；
4. **W 规则显式层**：法域、采购方政策、行业约束、披露范围与证据完成标准；
5. **P 过程层**：采集、上溯、筛查、评估、补证、导出、签名、验证、回放和规则迁移。

核心流程：

```text
ERP/MES/WMS/供应商文件
          ↓
标准化对象与批次事件
          ↓
追加式证据账本 ── SHA-256 审计链
          ↓
规则包 W ── 实体快照 / 证据要求 / 有效日期
          ↓
追溯 + 名称审查 + 时效 + 质量平衡
          ↓
开放 I + 补证任务 + 阶段 K
          ↓
公共护照 / 鉴证护照 / EPCIS / 案卷 ZIP
```

系统不让规则包静默改写历史。更新后的规则包生成新评估，旧评估、旧证据和旧摘要继续保留。

## English

TRACE81 treats a supply chain as five continuously generated record classes rather than a static vendor list: source continuity (D), explicit differences (I), stage-bounded passports (K), explicit rule and disclosure worlds (W), and executable trace/evaluate/remediate/export processes (P). Rule changes create new evaluations without overwriting prior evidence or history.
