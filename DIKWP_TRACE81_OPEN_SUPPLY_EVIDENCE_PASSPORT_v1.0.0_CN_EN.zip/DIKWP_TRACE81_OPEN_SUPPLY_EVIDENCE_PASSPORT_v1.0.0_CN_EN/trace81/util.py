from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def normalize_name(value: str) -> str:
    """Normalize entity names without pretending that normalization proves identity."""
    text = unicodedata.normalize("NFKC", value or "").casefold()
    text = re.sub(r"[\u2010-\u2015]", "-", text)
    text = re.sub(r"[^\w\s]", " ", text, flags=re.UNICODE)
    tokens = [t for t in text.split() if t]
    legal_suffixes = {
        "co", "company", "corp", "corporation", "inc", "incorporated", "limited",
        "ltd", "llc", "plc", "group", "holdings", "holding", "industry", "industries",
    }
    trimmed = [t for t in tokens if t not in legal_suffixes]
    return " ".join(trimmed or tokens)


def ensure_parent(path: str | Path) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def load_json(path: str | Path) -> Any:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def dump_json(path: str | Path, value: Any, *, indent: int = 2) -> Path:
    p = ensure_parent(path)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(value, fh, ensure_ascii=False, indent=indent, sort_keys=True)
        fh.write("\n")
    return p
