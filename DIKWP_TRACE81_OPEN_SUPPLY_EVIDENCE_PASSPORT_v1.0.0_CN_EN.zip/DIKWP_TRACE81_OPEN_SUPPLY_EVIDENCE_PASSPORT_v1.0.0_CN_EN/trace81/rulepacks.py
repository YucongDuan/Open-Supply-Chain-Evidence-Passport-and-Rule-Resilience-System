from __future__ import annotations

from importlib import resources
from pathlib import Path
from typing import Any

from .util import load_json, sha256_text, canonical_json

_BUILTINS = {
    "builtin:uflpa_us_2026-08-03": "uflpa_us_2026-08-03.json",
    "builtin:demo_watchlist": "demo_watchlist.json",
    "builtin:eu_espr_dpp_2026": "eu_espr_dpp_2026.json",
}


def _read_rulepack(path: str | Path) -> dict[str, Any]:
    key = str(path)
    if key in _BUILTINS:
        resource = resources.files("trace81.resources.rulepacks").joinpath(_BUILTINS[key])
        with resource.open("r", encoding="utf-8") as fh:
            import json
            return json.load(fh)
    return load_json(path)


def load_rulepack(path: str | Path) -> dict[str, Any]:
    data = _read_rulepack(path)
    required = {"id", "version", "title", "jurisdiction", "effective_date", "requirements", "legal_boundary"}
    missing = sorted(required - set(data))
    if missing:
        raise ValueError(f"Rule pack missing fields: {', '.join(missing)}")
    data["digest"] = sha256_text(canonical_json({k: v for k, v in data.items() if k != "digest"}))
    return data


def rulepack_summary(rulepack: dict[str, Any]) -> dict[str, Any]:
    entries = rulepack.get("entity_list_snapshot", {}).get("entries", [])
    return {
        "id": rulepack["id"],
        "version": rulepack["version"],
        "title": rulepack["title"],
        "jurisdiction": rulepack["jurisdiction"],
        "effective_date": rulepack["effective_date"],
        "requirements": len(rulepack.get("requirements", [])),
        "entity_entries": len(entries),
        "digest": rulepack.get("digest"),
    }


def diff_rulepacks(old_path: str | Path, new_path: str | Path) -> dict[str, Any]:
    old = load_rulepack(old_path)
    new = load_rulepack(new_path)
    old_entries = {e.get("id") or e.get("legal_name"): e for e in old.get("entity_list_snapshot", {}).get("entries", [])}
    new_entries = {e.get("id") or e.get("legal_name"): e for e in new.get("entity_list_snapshot", {}).get("entries", [])}
    old_req = {r["id"]: r for r in old.get("requirements", [])}
    new_req = {r["id"]: r for r in new.get("requirements", [])}

    def changed(a: dict[str, Any], b: dict[str, Any]) -> bool:
        return canonical_json(a) != canonical_json(b)

    return {
        "old": rulepack_summary(old),
        "new": rulepack_summary(new),
        "entity_entries": {
            "added": [new_entries[k] for k in sorted(new_entries.keys() - old_entries.keys())],
            "removed": [old_entries[k] for k in sorted(old_entries.keys() - new_entries.keys())],
            "changed": [
                {"key": k, "old": old_entries[k], "new": new_entries[k]}
                for k in sorted(old_entries.keys() & new_entries.keys())
                if changed(old_entries[k], new_entries[k])
            ],
        },
        "requirements": {
            "added": [new_req[k] for k in sorted(new_req.keys() - old_req.keys())],
            "removed": [old_req[k] for k in sorted(old_req.keys() - new_req.keys())],
            "changed": [
                {"key": k, "old": old_req[k], "new": new_req[k]}
                for k in sorted(old_req.keys() & new_req.keys())
                if changed(old_req[k], new_req[k])
            ],
        },
        "boundary": "This is a mechanical snapshot comparison, not legal interpretation.",
    }
