from __future__ import annotations

from difflib import SequenceMatcher
from typing import Any

from .util import normalize_name


def _names(entry: dict[str, Any]) -> list[str]:
    return [entry.get("legal_name", ""), *entry.get("aliases", [])]


def match_entity(name: str, aliases: list[str], entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    candidates = [name, *aliases]
    normalized_candidates = [(c, normalize_name(c)) for c in candidates if c]
    results: list[dict[str, Any]] = []
    for entry in entries:
        best = (0.0, "", "")
        for candidate_raw, candidate in normalized_candidates:
            for entry_name in _names(entry):
                norm_entry = normalize_name(entry_name)
                if not candidate or not norm_entry:
                    continue
                if candidate == norm_entry:
                    score = 1.0
                else:
                    score = SequenceMatcher(None, candidate, norm_entry).ratio()
                if score > best[0]:
                    best = (score, candidate_raw, entry_name)
        score, candidate_raw, matched_name = best
        if score >= 0.82:
            if score == 1.0:
                status = "EXACT_NAME_OR_ALIAS_MATCH"
            elif score >= 0.93:
                status = "HIGH_SIMILARITY_REVIEW"
            else:
                status = "POSSIBLE_MATCH_REVIEW"
            results.append({
                "status": status,
                "similarity": round(score, 4),
                "input_name": candidate_raw,
                "matched_name": matched_name,
                "entry_id": entry.get("id"),
                "entry_legal_name": entry.get("legal_name"),
                "criteria": entry.get("criteria", []),
                "effective_date": entry.get("effective_date"),
                "source_uri": entry.get("source_uri"),
                "notice": "A name match is a review signal, not a legal identity determination.",
            })
    return sorted(results, key=lambda r: (-r["similarity"], r["entry_legal_name"] or ""))
