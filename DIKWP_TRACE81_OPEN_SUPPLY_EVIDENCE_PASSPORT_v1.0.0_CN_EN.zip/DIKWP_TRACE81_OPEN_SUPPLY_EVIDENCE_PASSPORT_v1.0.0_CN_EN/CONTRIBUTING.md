# Contributing

TRACE81 welcomes source-code, rule-pack, schema, documentation, and interoperability contributions.

1. Do not submit confidential supplier data, personal data, trade secrets, or unverified allegations.
2. Every rule-pack change must identify its jurisdiction, source, effective date, version, and legal boundary.
3. Screening logic must preserve uncertainty. Name similarity is never an identity determination.
4. Do not add a single "compliance score" that hides evidence gaps or lets strengths cancel critical failures.
5. Tests are required for changes to graph traversal, rule-pack evaluation, export, signing, or the audit chain.
6. Demo data must remain fictional and clearly marked.

Use a signed-off contribution line when appropriate. Security issues should be reported privately rather than opened with exploitable details.
