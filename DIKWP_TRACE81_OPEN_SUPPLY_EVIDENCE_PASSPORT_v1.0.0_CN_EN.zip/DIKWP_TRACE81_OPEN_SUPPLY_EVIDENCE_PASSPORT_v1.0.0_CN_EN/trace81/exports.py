from __future__ import annotations

import html
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Any

from .evaluate import evaluate_case
from .graph import trace_lot
from .rulepacks import load_rulepack
from .store import Store
from .util import canonical_json, dump_json, sha256_file, sha256_text, utc_now


def _trace_subject_ids(trace: dict[str, Any]) -> set[str]:
    ids: set[str] = set()
    for key in ("organizations", "facilities", "products", "lots", "events"):
        ids.update(x["id"] for x in trace.get(key, []))
    return ids


def build_passport(store: Store, lot_id: str, *, view: str = "assurance") -> dict[str, Any]:
    if view not in {"public", "assurance"}:
        raise ValueError("view must be 'public' or 'assurance'")
    trace = trace_lot(store, lot_id)
    lot = store.get("lots", lot_id)
    if not lot:
        raise KeyError(lot_id)
    product = store.get("products", lot["product_id"])
    subject_ids = _trace_subject_ids(trace)
    evidence = [e for e in store.all("evidence") if e["subject_id"] in subject_ids]
    evidence_refs = [
        {
            "id": e["id"],
            "type": e["evidence_type"],
            "hash": e.get("file_hash"),
            "issuer": e.get("issuer") if view == "assurance" else None,
            "confidentiality": e["confidentiality"],
        }
        for e in evidence
        if view == "assurance" or e["confidentiality"] == "public"
    ]
    for item in evidence_refs:
        if item.get("issuer") is None:
            item.pop("issuer", None)
    passport = {
        "@context": [
            "https://www.w3.org/ns/credentials/v2",
            "https://ref.gs1.org/standards/epcis/epcis-context.jsonld",
        ],
        "type": ["VerifiableCredential", "Trace81SupplyEvidencePassport"],
        "id": f"urn:trace81:passport:{lot_id}:{view}",
        "issuer": "urn:trace81:demo-issuer",
        "validFrom": utc_now(),
        "credentialSubject": {
            "id": f"urn:trace81:lot:{lot_id}",
            "product": product,
            "lot": lot,
            "view": view,
            "chainSummary": {
                "organizations": len(trace["organizations"]),
                "facilities": len(trace["facilities"]),
                "lots": len(trace["lots"]),
                "events": len(trace["events"]),
            },
            "evidenceRefs": evidence_refs,
            "generationBoundary": "Current stage-bounded snapshot; not a permanent certification or legal conclusion.",
        },
        "credentialSchema": {
            "id": "urn:trace81:schema:supply-evidence-passport:v1",
            "type": "JsonSchema",
        },
        "interoperabilityProfiles": [
            "W3C Verifiable Credentials Data Model 2.0-inspired envelope",
            "GS1 EPCIS 2.0 event export available separately",
        ],
    }
    passport["trace81Digest"] = sha256_text(canonical_json(passport))
    return passport


def export_epcis(store: Store, lot_id: str) -> dict[str, Any]:
    trace = trace_lot(store, lot_id)
    event_list = []
    for event in trace["events"]:
        if event["event_type"] == "TransformationEvent":
            epcis_type = "TransformationEvent"
        elif event["event_type"] == "AggregationEvent":
            epcis_type = "AggregationEvent"
        elif event["event_type"] == "AssociationEvent":
            epcis_type = "AssociationEvent"
        else:
            epcis_type = "ObjectEvent"
        event_list.append({
            "type": epcis_type,
            "eventID": f"urn:trace81:event:{event['id']}",
            "eventTime": event["event_time"],
            "eventTimeZoneOffset": "+00:00",
            "bizStep": event.get("biz_step") or "urn:epcglobal:cbv:bizstep:commissioning",
            "disposition": event.get("disposition") or "urn:epcglobal:cbv:disp:active",
            "inputEPCList": [f"urn:trace81:lot:{x}" for x in event.get("input_lots_json", [])],
            "outputEPCList": [f"urn:trace81:lot:{x}" for x in event.get("output_lots_json", [])],
            "readPoint": {"id": f"urn:trace81:facility:{event.get('facility_id') or 'unknown'}"},
            "trace81:actor": event.get("actor_org_id"),
        })
    return {
        "@context": ["https://ref.gs1.org/standards/epcis/epcis-context.jsonld", {"trace81": "urn:trace81:"}],
        "type": "EPCISDocument",
        "schemaVersion": "2.0",
        "creationDate": utc_now(),
        "epcisBody": {"eventList": event_list},
        "boundary": "Reference export mapping; conformance must be tested against the target GS1 profile and partner implementation.",
    }


def _render_case_html(evaluation: dict[str, Any]) -> str:
    case = evaluation["case"]
    unresolved = evaluation["unresolved_signals"]
    rows = "".join(
        f"<tr><td>{html.escape(x['kind'])}</td><td>{html.escape(x['severity'])}</td><td><code>{html.escape(str(x['subject']))}</code></td></tr>"
        for x in unresolved
    ) or "<tr><td colspan='3'>No unresolved signals in this demonstration packet.</td></tr>"
    cov = "".join(
        f"<tr><td>{html.escape(x['requirement_id'])}</td><td>{html.escape(x['title'])}</td><td>{html.escape(x['status'])}</td></tr>"
        for x in evaluation["coverage"]
    )
    tasks = "".join(
        f"<li><b>{html.escape(t['priority'])}</b> — {html.escape(t['action'])}</li>"
        for t in evaluation.get("remediation_tasks", [])
    ) or "<li>No generated remediation tasks.</li>"
    return f"""<!doctype html><html lang='en'><meta charset='utf-8'><title>TRACE81 dossier</title>
<style>body{{font-family:system-ui;max-width:1100px;margin:40px auto;padding:0 24px;color:#14212b}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #cad5df;padding:8px;text-align:left}}th{{background:#eef3f6}}code{{font-size:.9em}}.warn{{background:#fff4d8;padding:14px;border-left:5px solid #d48b00}}</style>
<h1>TRACE81 evidence dossier</h1><p><b>Case:</b> {html.escape(case['name'])}</p><p><b>DIKWP vector:</b> {evaluation['dikwp_vector']} (structural review only)</p>
<div class='warn'>{html.escape(evaluation['conclusion_boundary'])}</div>
<h2>Evidence coverage</h2><table><tr><th>ID</th><th>Requirement</th><th>Status</th></tr>{cov}</table>
<h2>Unresolved signals</h2><table><tr><th>Kind</th><th>Severity</th><th>Subject</th></tr>{rows}</table>
<h2>Remediation tasks</h2><ul>{tasks}</ul>
<h2>Packet contents</h2><p>See JSON records, the source-evidence manifest, rule-pack snapshot, and SHA-256 manifest included with this dossier.</p></html>"""


def build_dossier(store: Store, case_id: str, rulepack_path: str | Path, output_zip: str | Path) -> Path:
    evaluation = evaluate_case(store, case_id, rulepack_path)
    lot_id = evaluation["shipment"]["product_lot_id"]
    with tempfile.TemporaryDirectory(prefix="trace81-dossier-") as tmp:
        root = Path(tmp) / f"TRACE81_DOSSIER_{case_id}"
        root.mkdir(parents=True)
        dump_json(root / "case_evaluation.json", evaluation)
        dump_json(root / "passport_assurance.json", build_passport(store, lot_id, view="assurance"))
        dump_json(root / "passport_public.json", build_passport(store, lot_id, view="public"))
        dump_json(root / "epcis_2_0.json", export_epcis(store, lot_id))
        dump_json(root / "audit_ledger.json", store.audit_rows())
        rulepack = load_rulepack(rulepack_path)
        dump_json(root / "rulepack_snapshot.json", {k: v for k, v in rulepack.items() if k != "digest"})
        evidence_dir = root / "evidence_files"
        evidence_dir.mkdir()
        manifest = []
        trace_ids = _trace_subject_ids(evaluation["trace"]) | {case_id, evaluation["shipment"]["id"]}
        for item in store.all("evidence"):
            if item["subject_id"] not in trace_ids:
                continue
            copied = None
            file_path = item.get("file_path")
            if file_path and Path(file_path).exists():
                copied = evidence_dir / f"{item['id']}_{Path(file_path).name}"
                shutil.copy2(file_path, copied)
            manifest.append({
                "evidence_id": item["id"],
                "type": item["evidence_type"],
                "title": item["title"],
                "issuer": item.get("issuer"),
                "issued_at": item.get("issued_at"),
                "valid_until": item.get("valid_until"),
                "source_uri": item.get("source_uri"),
                "declared_hash": item.get("file_hash"),
                "copied_file": copied.name if copied else None,
                "copied_hash": sha256_file(copied) if copied else None,
            })
        dump_json(root / "evidence_manifest.json", manifest)
        (root / "index.html").write_text(_render_case_html(evaluation), encoding="utf-8")
        (root / "LEGAL_BOUNDARY.txt").write_text(evaluation["conclusion_boundary"] + "\n", encoding="utf-8")
        hashes = []
        for path in sorted(p for p in root.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt"):
            hashes.append(f"{sha256_file(path)}  {path.relative_to(root).as_posix()}")
        (root / "SHA256SUMS.txt").write_text("\n".join(hashes) + "\n", encoding="utf-8")
        output = Path(output_zip)
        output.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for path in sorted(root.rglob("*")):
                if path.is_file():
                    zf.write(path, arcname=f"{root.name}/{path.relative_to(root).as_posix()}")
    return output
