#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
rm -f data/examples/trace81_demo.sqlite
rm -rf data/examples/evidence
mkdir -p artifacts
python -m trace81 demo --db data/examples/trace81_demo.sqlite --evidence-dir data/examples/evidence
python -m trace81 evaluate --db data/examples/trace81_demo.sqlite --case CASE-SNACK-US --rulepack builtin:uflpa_us_2026-08-03 --out artifacts/case_snack_us_evaluation.json
python -m trace81 passport --db data/examples/trace81_demo.sqlite --lot LOT-SNACK-001 --view assurance --out artifacts/passport_assurance.json
python -m trace81 epcis --db data/examples/trace81_demo.sqlite --lot LOT-SNACK-001 --out artifacts/epcis_2_0.json
python -m trace81 dossier --db data/examples/trace81_demo.sqlite --case CASE-SNACK-US --rulepack builtin:uflpa_us_2026-08-03 --out artifacts/TRACE81_DOSSIER_CASE-SNACK-US.zip
python -m unittest discover -s tests -v
