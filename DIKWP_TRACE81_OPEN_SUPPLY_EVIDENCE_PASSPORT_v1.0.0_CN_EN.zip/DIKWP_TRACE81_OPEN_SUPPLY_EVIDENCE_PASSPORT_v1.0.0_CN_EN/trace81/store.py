from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any, Iterable

from .util import canonical_json, sha256_text, utc_now

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS organizations (
  id TEXT PRIMARY KEY,
  legal_name TEXT NOT NULL,
  aliases_json TEXT NOT NULL DEFAULT '[]',
  country TEXT,
  region TEXT,
  address TEXT,
  registration_id TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS facilities (
  id TEXT PRIMARY KEY,
  org_id TEXT NOT NULL REFERENCES organizations(id),
  name TEXT NOT NULL,
  country TEXT,
  region TEXT,
  address TEXT,
  latitude REAL,
  longitude REAL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  gtin TEXT,
  sector TEXT,
  description TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS lots (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  facility_id TEXT REFERENCES facilities(id),
  quantity REAL,
  unit TEXT,
  produced_at TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  event_time TEXT NOT NULL,
  actor_org_id TEXT REFERENCES organizations(id),
  facility_id TEXT REFERENCES facilities(id),
  input_lots_json TEXT NOT NULL DEFAULT '[]',
  output_lots_json TEXT NOT NULL DEFAULT '[]',
  quantities_json TEXT NOT NULL DEFAULT '{}',
  biz_step TEXT,
  disposition TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS relations (
  id TEXT PRIMARY KEY,
  source_type TEXT NOT NULL,
  source_id TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT NOT NULL,
  relation_type TEXT NOT NULL,
  valid_from TEXT,
  valid_to TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS shipments (
  id TEXT PRIMARY KEY,
  product_lot_id TEXT NOT NULL REFERENCES lots(id),
  exporter_org_id TEXT REFERENCES organizations(id),
  importer_org_id TEXT REFERENCES organizations(id),
  origin_country TEXT,
  destination_country TEXT,
  departure_date TEXT,
  arrival_date TEXT,
  entry_number TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS evidence (
  id TEXT PRIMARY KEY,
  subject_type TEXT NOT NULL,
  subject_id TEXT NOT NULL,
  evidence_type TEXT NOT NULL,
  title TEXT NOT NULL,
  issuer TEXT,
  issued_at TEXT,
  valid_until TEXT,
  file_path TEXT,
  file_hash TEXT,
  source_uri TEXT,
  confidentiality TEXT NOT NULL DEFAULT 'restricted',
  claims_json TEXT NOT NULL DEFAULT '[]',
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS cases (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  shipment_id TEXT NOT NULL REFERENCES shipments(id),
  market TEXT NOT NULL,
  rulepack_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'OPEN',
  created_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS audit_log (
  seq INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp TEXT NOT NULL,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  object_type TEXT NOT NULL,
  object_id TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  prev_hash TEXT NOT NULL,
  event_hash TEXT NOT NULL
);
"""

JSON_COLUMNS = {
    "organizations": ["aliases_json", "metadata_json"],
    "facilities": ["metadata_json"],
    "products": ["metadata_json"],
    "lots": ["metadata_json"],
    "events": ["input_lots_json", "output_lots_json", "quantities_json", "metadata_json"],
    "relations": ["metadata_json"],
    "shipments": ["metadata_json"],
    "evidence": ["claims_json", "metadata_json"],
    "cases": ["metadata_json"],
}


class Store:
    def __init__(self, path: str | Path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "Store":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def set_meta(self, key: str, value: Any) -> None:
        self.conn.execute(
            "INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, canonical_json(value) if not isinstance(value, str) else value),
        )
        self.conn.commit()

    def get_meta(self, key: str, default: Any = None) -> Any:
        row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        if not row:
            return default
        value = row[0]
        try:
            return json.loads(value)
        except Exception:
            return value

    def upsert(self, table: str, row: dict[str, Any], *, actor: str = "system", audit: bool = True) -> None:
        if table not in JSON_COLUMNS and table not in {"meta"}:
            raise ValueError(f"Unsupported table: {table}")
        data = dict(row)
        for col in JSON_COLUMNS.get(table, []):
            value = data.get(col)
            if value is None:
                continue
            if not isinstance(value, str):
                data[col] = canonical_json(value)
        cols = list(data)
        placeholders = ",".join("?" for _ in cols)
        updates = ",".join(f"{c}=excluded.{c}" for c in cols if c != "id")
        sql = f"INSERT INTO {table}({','.join(cols)}) VALUES({placeholders})"
        if "id" in cols:
            sql += f" ON CONFLICT(id) DO UPDATE SET {updates}"
        self.conn.execute(sql, [data[c] for c in cols])
        self.conn.commit()
        if audit and "id" in data:
            self.append_audit(actor, f"UPSERT_{table.upper()}", table, str(data["id"]), row)

    def insert_many(self, table: str, rows: Iterable[dict[str, Any]], *, actor: str = "system") -> None:
        for row in rows:
            self.upsert(table, row, actor=actor)

    def get(self, table: str, object_id: str) -> dict[str, Any] | None:
        row = self.conn.execute(f"SELECT * FROM {table} WHERE id=?", (object_id,)).fetchone()
        return self._decode(table, row) if row else None

    def all(self, table: str, where: str = "", params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        sql = f"SELECT * FROM {table}"
        if where:
            sql += " WHERE " + where
        rows = self.conn.execute(sql, params).fetchall()
        return [self._decode(table, row) for row in rows]

    def _decode(self, table: str, row: sqlite3.Row) -> dict[str, Any]:
        data = dict(row)
        for col in JSON_COLUMNS.get(table, []):
            try:
                data[col] = json.loads(data[col])
            except Exception:
                pass
        return data

    def append_audit(self, actor: str, action: str, object_type: str, object_id: str, payload: Any) -> str:
        prev = self.conn.execute("SELECT event_hash FROM audit_log ORDER BY seq DESC LIMIT 1").fetchone()
        prev_hash = prev[0] if prev else "0" * 64
        timestamp = utc_now()
        payload_json = canonical_json(payload)
        material = canonical_json({
            "timestamp": timestamp,
            "actor": actor,
            "action": action,
            "object_type": object_type,
            "object_id": object_id,
            "payload": json.loads(payload_json),
            "prev_hash": prev_hash,
        })
        event_hash = sha256_text(material)
        self.conn.execute(
            "INSERT INTO audit_log(timestamp,actor,action,object_type,object_id,payload_json,prev_hash,event_hash) VALUES(?,?,?,?,?,?,?,?)",
            (timestamp, actor, action, object_type, object_id, payload_json, prev_hash, event_hash),
        )
        self.conn.commit()
        return event_hash

    def verify_audit(self) -> dict[str, Any]:
        rows = self.conn.execute("SELECT * FROM audit_log ORDER BY seq").fetchall()
        prev_hash = "0" * 64
        failures: list[dict[str, Any]] = []
        for row in rows:
            material = canonical_json({
                "timestamp": row["timestamp"],
                "actor": row["actor"],
                "action": row["action"],
                "object_type": row["object_type"],
                "object_id": row["object_id"],
                "payload": json.loads(row["payload_json"]),
                "prev_hash": prev_hash,
            })
            expected = sha256_text(material)
            if row["prev_hash"] != prev_hash or row["event_hash"] != expected:
                failures.append({"seq": row["seq"], "expected": expected, "actual": row["event_hash"]})
            prev_hash = row["event_hash"]
        return {
            "valid": not failures,
            "events": len(rows),
            "head": prev_hash,
            "failures": failures,
        }

    def audit_rows(self) -> list[dict[str, Any]]:
        rows = self.conn.execute("SELECT * FROM audit_log ORDER BY seq").fetchall()
        out = []
        for row in rows:
            item = dict(row)
            item["payload_json"] = json.loads(item["payload_json"])
            out.append(item)
        return out
