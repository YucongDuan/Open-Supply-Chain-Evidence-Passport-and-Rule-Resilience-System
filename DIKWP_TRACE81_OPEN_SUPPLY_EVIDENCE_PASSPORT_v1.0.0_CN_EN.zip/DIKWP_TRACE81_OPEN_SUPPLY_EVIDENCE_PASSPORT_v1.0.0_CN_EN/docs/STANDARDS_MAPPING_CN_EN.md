# Standards mapping / 标准映射

| TRACE81 能力 | 参考标准或制度 | 映射边界 |
|---|---|---|
| 批次与事件追溯 | GS1 EPCIS 2.0 / CBV | 参考导出；生产环境需按具体 GS1 标识与伙伴配置进行一致性测试 |
| 数字证据护照 | W3C Verifiable Credentials Data Model 2.0 | 采用 issuer-holder-verifier 与防篡改凭证思路；本版本不是认证实现 |
| 可选签名 | Ed25519 / 数据完整性思路 | 使用确定性 JSON 序列化参考方案；不得宣称完整兼容特定 W3C cryptosuite |
| 欧盟产品数据准备 | ESPR Digital Product Passport | 通用数据准备；食品通常不属于 ESPR 产品范围，应使用相应海关/买方证据包 |
| UFLPA 证据准备 | DHS/FLETF/CBP 公开名单和进口商指引 | 规则包不替代法律意见，也不保证达到个案证据标准 |

TRACE81 的互操作策略是“映射而不冒充”：输出尽量接近公开标准，但每个导出都保留版本、来源和一致性边界。
