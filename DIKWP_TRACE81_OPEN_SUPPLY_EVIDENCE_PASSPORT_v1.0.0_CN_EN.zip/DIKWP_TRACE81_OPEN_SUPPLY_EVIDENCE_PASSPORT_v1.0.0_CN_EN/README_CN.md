# DIKWP-MESH8.1 TRACE81（溯证81）

**全球供应链证据护照与规则韧性开源系统**  
**Prove the chain, not just manage it.｜不仅管理供应链，更要证明供应链。**

TRACE81 面向出口企业、进口商、采购方、律师、审计机构、银行保险与产业园区，把零散的供应商资料、批次事件、原产地记录、劳动尽调、交易与物流文件组织成可追溯、可版本化、可携带、可复核的供应链证据包。

它不输出“企业合规/不合规”的黑箱总分，也不把名称相似当作实体身份。它保存：

- D：来源记录、事件、文件摘要和跨版本保持内容；
- I：缺失、冲突、过期、名称不确定性、数量不平衡及其他差异；
- K：当前阶段、当前批次和当前规则包下的证据护照；
- W：市场、法域、规则版本、采购方要求和披露边界；
- P：追溯、筛查、评估、补证、导出、签名、复核和回放过程。

`11111` 仅表示五类审查结构可运行，不代表法律合规、货物可入境、实体身份成立或强迫劳动事实判断。

## 关键功能

- SQLite 本地证据账本与追加式 SHA-256 审计链；
- 产品、批次、工厂、企业、转换事件和运输关系的多层上溯；
- 规则包版本化与差分；
- 名称/别名筛查并保留身份不确定性；
- 证据覆盖、时效、质量平衡和补证任务生成；
- 公共视图与鉴证视图两种数字证据护照；
- GS1 EPCIS 2.0 风格事件导出；
- W3C VC 2.0 启发式证据凭证封装与可选 Ed25519 签名；
- 可移交的证据案卷 ZIP、文件清单和摘要验证；
- 单文件离线展示系统；
- 纯 Python 标准库核心，密码签名为可选依赖。

## 快速运行

```bash
python -m trace81 demo \
  --db data/examples/trace81_demo.sqlite \
  --evidence-dir data/examples/evidence

python -m trace81 evaluate \
  --db data/examples/trace81_demo.sqlite \
  --case CASE-SNACK-US \
  --rulepack builtin:uflpa_us_2026-08-03 \
  --out artifacts/case_snack_us_evaluation.json

python -m trace81 dossier \
  --db data/examples/trace81_demo.sqlite \
  --case CASE-SNACK-US \
  --rulepack builtin:uflpa_us_2026-08-03 \
  --out artifacts/TRACE81_DOSSIER_CASE-SNACK-US.zip
```

也可直接运行发行包中的：

```bash
python dist/TRACE81.pyz --help
```

## 官方规则快照边界

随附 `US-UFLPA-2026-08-03` 规则包仅包含 2026-08-03 生效的 **43 家新增实体**，不是全部 187 家 UFLPA 实体清单，不能作为唯一筛查源。实际项目必须同步最新官方名单、CBP 指引、进口商记录和个案法律意见。

## 商业化建议

代码采用 Apache-2.0。可收费层包括私有部署、ERP/MES/WMS 连接器、供应商协作门户、规则情报订阅、证据包托管生成、第三方审计接口、行业规则包和 TRACE81 Conformance 测试。建议将 **TRACE81/溯证81** 名称及认证标志保留为项目商标和一致性标识。

详见 `docs/COMMERCIALIZATION_AND_REPUTATION_PLAN_CN_EN.md`。

## 开放协议与一致性

- `docs/SECP_SUPPLY_EVIDENCE_CONTINUITY_PROTOCOL_DRAFT_CN_EN.md`：Supply Evidence Continuity Protocol 0.1 开放草案；
- `docs/TRACE81_CONFORMANCE_PROFILE_CN_EN.md`：只核验软件数据/接口行为的 C01-C10 配置，不认证企业事实或法律结论。
