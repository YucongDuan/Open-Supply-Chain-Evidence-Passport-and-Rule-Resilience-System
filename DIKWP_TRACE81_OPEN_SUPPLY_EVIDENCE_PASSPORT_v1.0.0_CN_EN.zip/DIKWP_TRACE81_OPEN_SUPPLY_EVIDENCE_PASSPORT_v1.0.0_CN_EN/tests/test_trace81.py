from __future__ import annotations

import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from trace81.crypto import keygen, sign_document, verify_document
from trace81.demo import create_demo
from trace81.evaluate import evaluate_case
from trace81.exports import build_dossier, build_passport, export_epcis
from trace81.graph import mass_balance_checks, organization_paths, trace_lot
from trace81.rulepacks import diff_rulepacks, load_rulepack, rulepack_summary
from trace81.screening import match_entity
from trace81.store import Store
from trace81.util import canonical_json, sha256_text


ROOT = Path(__file__).resolve().parents[1]
UFLPA = ROOT / "data" / "rulepacks" / "uflpa_us_2026-08-03.json"
DEMO_WATCH = ROOT / "data" / "rulepacks" / "demo_watchlist.json"


class Trace81Test(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.db = self.root / "demo.sqlite"
        self.evidence = self.root / "evidence"
        with Store(self.db) as store:
            create_demo(store, self.evidence)

    def tearDown(self):
        self.tmp.cleanup()

    def test_demo_counts_and_audit(self):
        with Store(self.db) as store:
            self.assertEqual(len(store.all("organizations")), 7)
            self.assertEqual(len(store.all("lots")), 6)
            self.assertEqual(len(store.all("evidence")), 13)
            self.assertTrue(store.verify_audit()["valid"])

    def test_official_increment_snapshot_shape(self):
        rp = load_rulepack(UFLPA)
        entries = rp["entity_list_snapshot"]["entries"]
        self.assertEqual(len(entries), 43)
        ii = sum("UFLPA_2d2Bii" in e["criteria"] for e in entries)
        v = sum("UFLPA_2d2Bv" in e["criteria"] for e in entries)
        overlap = sum(len(e["criteria"]) > 1 for e in entries)
        self.assertEqual((ii, v, overlap), (4, 41, 2))
        self.assertEqual(rp["entity_list_snapshot"]["official_total_after_update"], 187)

    def test_builtin_rulepack(self):
        a = load_rulepack(UFLPA)
        b = load_rulepack("builtin:uflpa_us_2026-08-03")
        self.assertEqual(a["digest"], b["digest"])

    def test_rulepack_digest_deterministic(self):
        a = load_rulepack(UFLPA)
        b = load_rulepack(UFLPA)
        self.assertEqual(a["digest"], b["digest"])
        self.assertEqual(rulepack_summary(a)["entity_entries"], 43)

    def test_rulepack_diff(self):
        diff = diff_rulepacks(DEMO_WATCH, UFLPA)
        self.assertTrue(diff["entity_entries"]["added"])
        self.assertIn("mechanical", diff["boundary"])

    def test_trace_upstream(self):
        with Store(self.db) as store:
            trace = trace_lot(store, "LOT-SNACK-001")
        self.assertEqual(len(trace["organizations"]), 4)
        self.assertEqual(len(trace["events"]), 4)
        self.assertIn("LOT-SEED-001", {x["id"] for x in trace["lots"]})

    def test_organization_paths(self):
        with Store(self.db) as store:
            trace = trace_lot(store, "LOT-SNACK-001")
        paths = organization_paths(trace, "LOT-SNACK-001")
        self.assertEqual(paths["ORG-FARM"][0], "ORG-FARM")
        self.assertEqual(paths["ORG-FARM"][-1], "LOT-SNACK-001")

    def test_mass_balance_by_unit(self):
        with Store(self.db) as store:
            trace = trace_lot(store, "LOT-SNACK-001")
        checks = mass_balance_checks(trace)
        self.assertEqual({x["unit"] for x in checks}, {"kg", "each"})
        self.assertTrue(all(x["status"] == "BALANCED_OR_LOSS" for x in checks))

    def test_snack_evaluation_preserves_stale_gap(self):
        with Store(self.db) as store:
            result = evaluate_case(store, "CASE-SNACK-US", UFLPA)
        self.assertEqual(result["dikwp_vector"], "11111")
        self.assertEqual(result["evidence_state"], "READY_WITH_STALE_EVIDENCE")
        self.assertEqual(result["coverage_counts"]["STALE"], 1)
        self.assertEqual(result["remediation_tasks"][0]["priority"], "P1")
        self.assertNotIn("compliance_score", result)
        self.assertIn("does not determine legal compliance", result["conclusion_boundary"])

    def test_demo_watchlist_match(self):
        with Store(self.db) as store:
            result = evaluate_case(store, "CASE-DEMO-MATCH", DEMO_WATCH)
        self.assertEqual(result["evidence_state"], "IDENTITY_REVIEW_REQUIRED")
        self.assertEqual(result["screening"][0]["status"], "EXACT_NAME_OR_ALIAS_MATCH")
        self.assertTrue(any(x["kind"] == "ENTITY_MATCH_REVIEW" for x in result["unresolved_signals"]))

    def test_screening_does_not_claim_identity(self):
        rp = load_rulepack(DEMO_WATCH)
        entries = rp["entity_list_snapshot"]["entries"]
        result = match_entity("DR Fiber", [], entries)[0]
        self.assertIn("not a legal identity determination", result["notice"])

    def test_public_and_assurance_passports(self):
        with Store(self.db) as store:
            public = build_passport(store, "LOT-SNACK-001", view="public")
            assurance = build_passport(store, "LOT-SNACK-001", view="assurance")
        p = public["credentialSubject"]["evidenceRefs"]
        a = assurance["credentialSubject"]["evidenceRefs"]
        self.assertLess(len(p), len(a))
        self.assertTrue(all(x["confidentiality"] == "public" for x in p))
        self.assertNotEqual(public["trace81Digest"], assurance["trace81Digest"])

    def test_passport_digest_is_self_consistent(self):
        with Store(self.db) as store:
            p = build_passport(store, "LOT-SNACK-001")
        digest = p.pop("trace81Digest")
        self.assertEqual(digest, sha256_text(canonical_json(p)))

    def test_epcis_reference_export(self):
        with Store(self.db) as store:
            doc = export_epcis(store, "LOT-SNACK-001")
        self.assertEqual(doc["schemaVersion"], "2.0")
        self.assertEqual(len(doc["epcisBody"]["eventList"]), 4)
        self.assertIn("Reference export", doc["boundary"])

    def test_dossier_contains_manifests(self):
        out = self.root / "dossier.zip"
        with Store(self.db) as store:
            build_dossier(store, "CASE-SNACK-US", UFLPA, out)
        with zipfile.ZipFile(out) as zf:
            names = zf.namelist()
        self.assertTrue(any(n.endswith("SHA256SUMS.txt") for n in names))
        self.assertTrue(any(n.endswith("case_evaluation.json") for n in names))
        self.assertTrue(any("evidence_files/" in n for n in names))

    def test_audit_tamper_detection(self):
        with Store(self.db) as store:
            store.conn.execute("UPDATE audit_log SET event_hash='x' WHERE seq=1")
            store.conn.commit()
            self.assertFalse(store.verify_audit()["valid"])

    def test_unknown_case(self):
        with Store(self.db) as store:
            with self.assertRaises(KeyError):
                evaluate_case(store, "NO-SUCH-CASE", UFLPA)

    def test_optional_signature(self):
        try:
            import cryptography  # noqa: F401
        except ImportError:
            self.skipTest("cryptography not installed")
        private = self.root / "private.pem"
        public = self.root / "public.pem"
        keygen(private, public)
        document = {"id": "urn:test", "value": 1}
        signed = sign_document(document, private, "did:key:demo#key-1")
        self.assertTrue(verify_document(signed, public))
        signed["value"] = 2
        self.assertFalse(verify_document(signed, public))

    def test_json_canonicalization(self):
        self.assertEqual(canonical_json({"b": 1, "a": 2}), '{"a":2,"b":1}')


if __name__ == "__main__":
    unittest.main()
