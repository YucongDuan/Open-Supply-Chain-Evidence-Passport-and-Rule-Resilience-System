from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Any

from .util import canonical_json


def _crypto():
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
    except ImportError as exc:
        raise RuntimeError("Install optional dependency with: pip install 'trace81[crypto]'") from exc
    return serialization, Ed25519PrivateKey, Ed25519PublicKey


def keygen(private_path: str | Path, public_path: str | Path) -> None:
    serialization, Ed25519PrivateKey, _ = _crypto()
    key = Ed25519PrivateKey.generate()
    private_bytes = key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_bytes = key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    Path(private_path).write_bytes(private_bytes)
    Path(public_path).write_bytes(public_bytes)


def sign_document(document: dict[str, Any], private_path: str | Path, verification_method: str) -> dict[str, Any]:
    serialization, _, _ = _crypto()
    private_key = serialization.load_pem_private_key(Path(private_path).read_bytes(), password=None)
    unsigned = dict(document)
    unsigned.pop("proof", None)
    payload = canonical_json(unsigned).encode("utf-8")
    signature = private_key.sign(payload)
    signed = dict(unsigned)
    signed["proof"] = {
        "type": "DataIntegrityProof",
        "cryptosuite": "eddsa-jcs-2022-compatible-demo",
        "verificationMethod": verification_method,
        "proofPurpose": "assertionMethod",
        "proofValue": base64.urlsafe_b64encode(signature).decode("ascii").rstrip("="),
        "canonicalization": "RFC8785-like sorted JSON used by TRACE81 reference implementation",
    }
    return signed


def verify_document(document: dict[str, Any], public_path: str | Path) -> bool:
    serialization, _, _ = _crypto()
    proof = document.get("proof") or {}
    value = proof.get("proofValue")
    if not value:
        return False
    padding = "=" * (-len(value) % 4)
    signature = base64.urlsafe_b64decode(value + padding)
    unsigned = dict(document)
    unsigned.pop("proof", None)
    payload = canonical_json(unsigned).encode("utf-8")
    public_key = serialization.load_pem_public_key(Path(public_path).read_bytes())
    try:
        public_key.verify(signature, payload)
        return True
    except Exception:
        return False
